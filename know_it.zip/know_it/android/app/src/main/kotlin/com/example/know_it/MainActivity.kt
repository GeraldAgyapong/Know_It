package com.example.know_it

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
