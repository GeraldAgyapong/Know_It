class AppConstants {
  static const String appName = 'Know It?!';
}
